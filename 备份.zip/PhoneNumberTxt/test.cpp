#include <Python.h>
#include <stdio.h>
#include <string.h>

typedef struct Person {
  char name[100];
  char pinyin[120];
  char phonenumber[20];
  char location[100];
  struct Person* next;
} Person;

void cython1();
char* cython2(char* s);

int main() {
  Person* person;
  person = (Person*)malloc(sizeof(Person));
  // char ch[100] = "我是测试";
  printf("请输入联系人姓名：");
  scanf("%s", person->name);
  // fflush(stdin);  // fflush(stdin)刷新标准输入缓冲区
  printf("请输入联系人电话号码：");
  scanf("%s", person->phonenumber);
  // fflush(stdin);  // fflush(stdin)刷新标准输入缓冲区
  printf("请输入联系人地址：");
  scanf("%s", person->location);
  // fflush(stdin);  // fflush(stdin)刷新标准输入缓冲区
  // cython1();
  char* result = cython2(person->name);
  strcpy(person->pinyin, result);
  printf("我是拼音%s", person->pinyin);
  return 0;
}

char* cython2(char* s) {
  // 初始化
  Py_Initialize();
  // 运行两条简单python语句
  PyRun_SimpleString("import sys");
  PyRun_SimpleString("sys.path.append('./')");
  // 扩展sys路径到pip安装第三方包地址
  PyRun_SimpleString(
      "sys.path.append('C:/msys64/mingw64/lib/python3.9/site-packages')");
  // 导入模块
  PyObject* pModule = PyImport_ImportModule("convertCN2Spell");
  // 导入模块中的函数
  PyObject* pFunc = PyObject_GetAttrString(pModule, "convertCN2Spell");
  // 将输入参数转换为python数据类型
  PyObject* pArgs = PyTuple_New(1);
  PyTuple_SetItem(pArgs, 0, Py_BuildValue("s", s));
  // 调用函数
  PyObject* pValue = PyObject_CallObject(pFunc, pArgs);
  if (PyErr_Occurred()) {
    PyErr_PrintEx(0);
    PyErr_Clear();
  }
  // 将返回字符串类型转换为c字符串类型
  char* result;
  PyArg_Parse(pValue, "s", &result);
  printf("返回值1：%s\n", result);
  // 释放
  Py_Finalize();
  printf("返回值2：%s\n", result);
  return result;
}